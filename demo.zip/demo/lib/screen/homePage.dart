import 'dart:html';

import 'package:demo/api.dart';
import 'package:demo/screen/Home.dart';
import 'package:demo/screen/HomePage.dart';
import 'package:demo/screen/Profile.dart';
import 'package:demo/screen/blogPage.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int counter = 0;

  @override
  Widget build(BuildContext context) {
    List<Widget> pages = [BlogPage(), Profile()];

    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                child: Column(
              children: [
                Container(
                  height: 75,
                  width: 100,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.amber),
                ),
                SizedBox(
                  height: 10,
                ),
                ListTile(
                  title: Text("all post"),
                )
              ],
            ))
          ],
        ),
      ),
      appBar: AppBar(
        title: counter == 0 ? Text('Blog') : Text('Profile'),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => Home()));
        },
        child: Text('+'),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        notchMargin: 12,
        child: Container(
          height: 60,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                    onPressed: (() {
                      setState(() {
                        counter = 0;
                      });
                    }),
                    icon: Icon(Icons.home)),
                IconButton(
                    onPressed: (() {
                      setState(() {
                        counter = 1;
                      });
                    }),
                    icon: Icon(Icons.person)),
              ],
            ),
          ),
        ),
      ),
      body: pages[counter],
    );
  }
}
