import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import "package:http/http.dart" as http;

Future<Album> fetchAlbum() async {
  final http.Response response =
      await http.get(Uri.parse('http://localhost:3000/'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.

    return Album.fromJson(jsonDecode(response.body));
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
  }
}

class Album {
  final String name;
  final String title;
  final String desc;
  final String photo;

  const Album(
      {required this.name,
      required this.title,
      required this.desc,
      required this.photo});

  factory Album.fromJson(Map<String, dynamic> json) {
    return Album(
        name: json['name'],
        title: json['title'],
        desc: json['esc'],
        photo: json['photo']);
  }
}

Future<List<Blog>> fetchBlog() async {
  final response =
      await http.get(Uri.parse('http://localhost:3000/post/find/all'));
  // print(response.body);
  //print(url);
  //final res = jsonDecode(response.body);
  //print(res.data);
  //print(res.data[0]);

  // List jresponse = res;
  print(response.statusCode);
  //return jresponse.map<Blog>((e) => Blog.fromJson(e)).toList();
  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    print(response.statusCode);
    //print(response.body);
    final jresponse = json.decode(response.body);
    print(jresponse["data"]);
    print(jresponse); //Blog.fromJson(jsonDecode(response.body));
    return jresponse['data'].map<Blog>((e) => Blog.fromJson(e)).toList();
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load blogss');
  }
}

class Blog {
  final String header;
  final String title;
  final String desc;
  final String photo;

  const Blog(
      {required this.header,
      required this.title,
      required this.desc,
      required this.photo});

  factory Blog.fromJson(Map<String, dynamic> json) {
    return Blog(
        header: json['header'],
        title: json['title'],
        desc: json['desc'],
        photo: json['photo']);
  }
}

Future<User> fetchUser() async {
  final response =
      await http.get(Uri.parse('http://localhost:3000/user/michel'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return User.fromJson(jsonDecode(response.body));
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
  }
}

class User {
  final String username;
  final String email;
  final String password;

  const User({
    required this.username,
    required this.email,
    required this.password,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      username: json['username'],
      email: json['email'],
      password: json['password'],
    );
  }
}

String base = 'http://localhost:3000/user';
String base2 = 'http://localhost:3000/post';

Future get(String url) async {
  url = formater(url);
  var response = await http.get(Uri.parse(url));

  if (response.statusCode == 200 || response.statusCode == 201) {
    return json.decode(response.body);
  }
}

Future get2(String url) async {
  url = formater2(url);
  var response = await http.get(Uri.parse(url));

  if (response.statusCode == 200 || response.statusCode == 201) {
    return json.decode(response.body);
  }
}

Future<dynamic> post(String url, Map<String, String> body) async {
  url = formater(url);
  var response = await http.post(Uri.parse(url),
      headers: {"Content-type": "application/json"}, body: json.encode(body));

  print(response);
  return response;
}

Future<dynamic> post2(String url, Map<String, String> body) async {
  url = formater2(url);
  var response = await http.post(Uri.parse(url),
      headers: {"Content-type": "application/json"}, body: json.encode(body));

  print(response);
  return response;
}

String formater(String url) {
  return base + url;
}

String formater2(String url) {
  return base2 + url;
}
