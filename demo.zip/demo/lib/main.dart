import 'package:demo/screen/homePage.dart';
import 'package:demo/screen/login.dart';
import 'package:flutter/material.dart';
import 'package:demo/screen/blogPage.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Future take() async {
    final storage = new FlutterSecureStorage();
    return await storage.read(key: "token");
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Login(),
    ); //const MyHomePage(title: 'Flutter Demo Home Page'),
  }
}
