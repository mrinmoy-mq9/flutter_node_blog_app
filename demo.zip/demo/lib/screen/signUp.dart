import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:demo/api.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignInState();
}

class _SignInState extends State<SignUp> with TickerProviderStateMixin {
  final TextEditingController _emailCnt = TextEditingController();
  final TextEditingController _passwordCnt = TextEditingController();
  final TextEditingController _usernameCnt = TextEditingController();
  late String errString;
  late bool circular = false;
  late bool validate = true;

  late AnimationController _controler1;
  late Animation<Offset> animation2;

  var vis = true;
  final _globalKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controler1 = AnimationController(
        duration: Duration(milliseconds: 1400), vsync: this);

    animation2 = Tween<Offset>(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
        .animate(CurvedAnimation(parent: _controler1, curve: Curves.easeInOut));

    _controler1.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controler1.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Map<String, String> data;
    return Scaffold(
      body: Center(
        child: Form(
          key: _globalKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Center(
                  child: Text(
                'Sign In',
                style: TextStyle(color: Colors.purple, fontSize: 36),
              )),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'username is empty';
                            }),
                            controller: _usernameCnt,
                            onChanged: (v) => {_usernameCnt.text = v},
                            decoration: const InputDecoration(
                              helperText: "type your email",
                              helperStyle:
                                  TextStyle(color: Colors.red, fontSize: 10),
                              border: UnderlineInputBorder(),
                              labelText: "email",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'email is empty';
                              if (!value.contains("@")) {
                                return 'this is not an email';
                              }
                            }),
                            controller: _emailCnt,
                            onChanged: (v) => {_emailCnt.text = v},
                            decoration: const InputDecoration(
                              helperText: "type your email",
                              helperStyle:
                                  TextStyle(color: Colors.red, fontSize: 10),
                              border: UnderlineInputBorder(),
                              labelText: "email",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'email is empty';
                              if (value.length <= 8) {
                                return 'password must be greater then 8';
                              }
                            }),
                            obscureText: vis,
                            controller: _passwordCnt,
                            onChanged: (v) => {_passwordCnt.text = v},
                            decoration: InputDecoration(
                              helperText:
                                  "type your paasword more then 8 chracter",
                              helperStyle:
                                  TextStyle(color: Colors.red, fontSize: 10),
                              suffixIcon: IconButton(
                                icon: Icon(vis
                                    ? Icons.visibility_off
                                    : Icons.visibility),
                                onPressed: () => {
                                  setState(
                                    () {
                                      vis = !vis;
                                    },
                                  )
                                },
                              ),
                              border: UnderlineInputBorder(
                                  borderSide: BorderSide(
                                color: Colors.black45,
                                width: 2,
                              )),
                              labelText: "password",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SizedBox(
                height: 20,
              ),
              SlideTransition(
                position: animation2,
                child: circular
                    ? CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: () async {
                          setState(() => {circular = true});
                          print(' mrinmoy .....');
                          // await checkUser();
                          print('end mrinmoy....');
                          if (_globalKey.currentState!.validate() && validate) {
                            Map<String, String> data = {
                              "username": _usernameCnt.text,
                              "email": _emailCnt.text,
                              "password": _passwordCnt.text
                            };
                            print(data);
                            post("user/register", data);
                            setState(() {
                              circular = false;
                              errString = 'yes new user michel';
                            });
                          } else {
                            setState(() {
                              circular = false;
                            });
                          }
                        },
                        child: const Text(
                          'sigUp here',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        )),
              )
            ],
          ),
        ),
      ),
    );
  }

  checkUser() async {
    if (_usernameCnt.text.length == 0) {
      setState(() {
        circular = false;
        validate = false;
        errString = 'username cannot be empty';
      });
    } else {
      var response = await get('/user/checkusername/${_usernameCnt.text}');
      if (response["status"]) {
        setState(() {
          validate = false;
          errString = "username already taken";
        });
      } else {
        setState(() {
          validate = true;
        });
      }
    }
  }
}
