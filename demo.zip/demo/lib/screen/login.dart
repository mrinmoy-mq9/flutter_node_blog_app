import 'package:flutter/material.dart';
import 'package:demo/screen/signUp.dart';
import "package:demo/screen/signIn.dart";
import "package:demo/screen/HomePage.dart";

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> with TickerProviderStateMixin {
  late AnimationController _controler;
  late Animation<Offset> animation;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controler = AnimationController(
        duration: Duration(milliseconds: 1500), vsync: this);

    animation = Tween<Offset>(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
        .animate(CurvedAnimation(parent: _controler, curve: Curves.easeInOut));

    _controler.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controler.dispose();
  }

  final TextEditingController _emailCnt = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar: AppBar( title: Center( child: Text('LOgin'),),),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SlideTransition(
              position: animation,
              child: Text(
                'Login',
                style: TextStyle(
                  color: Colors.purple.shade500,
                  fontSize: 24,
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            button("google login"),
            SizedBox(
              height: 10,
            ),
            button("email"),
            SizedBox(
              height: 10,
            ),
            ElevatedButton(
                onPressed: () => {
                      Navigator.push(context,
                          MaterialPageRoute(builder: ((context) => SignIn())))
                    },
                child: Text(
                  'sign In here',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ))
          ],
        ),
      ),
    );
  }

  Widget button(String txt) {
    return SlideTransition(
      position: animation,
      child: InkWell(
        onTap: (() {
          txt == 'email'
              ? Navigator.push(
                  context, MaterialPageRoute(builder: ((context) => SignUp())))
              : null;
        }),
        child: Container(
          height: 100,
          width: 300,
          // color: Colors.blue,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Card(
              color: Colors.blueAccent,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.access_alarm),
                  SizedBox(
                    width: 20,
                  ),
                  Text(
                    txt,
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
