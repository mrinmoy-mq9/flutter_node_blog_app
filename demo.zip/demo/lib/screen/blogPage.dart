import 'package:demo/api.dart';
import 'package:flutter/material.dart';
import 'package:demo/screen/detail.dart';

class BlogPage extends StatefulWidget {
  const BlogPage({super.key});

  @override
  State<BlogPage> createState() => _BlogPageState();
}

class _BlogPageState extends State<BlogPage> {
  late Future<List<Blog>> blogs;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    blogs = fetchBlog();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<Blog>>(
            future: blogs,
            builder: (context, snapshot) {
              //print(blogs);
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: ((context, index) {
                    return Card(
                      elevation: 1,
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 200,
                              // width: 200,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      fit: BoxFit.contain,
                                      image: NetworkImage(
                                          "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIAAzgMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAECAwUGB//EAD0QAAICAQIEBAMFBAgHAAAAAAECAAMRBCESMUFRBRMiYRRxkQYygaHBFVKSsRYjM0JDU4LRJERicoOT8f/EABkBAAMBAQEAAAAAAAAAAAAAAAACAwEEBf/EACkRAAICAQMDAwMFAAAAAAAAAAABAhEDBBIhEzFBBRRRIkKhIyQyUnH/2gAMAwEAAhEDEQA/APIOG2v0sDJUjhcMRnuO8MZqNQPQgQ9AHzA3yj7cRA5gyyLygou07LVqU2bkKp5Ey7FdY4eJio642g1bq2dsg9zj6S1LCQV4duQg0xoNIn5KW8uEn6Si3RuhypH1ltYIf0ek95c11gAW6tD7kbzKY22Elz3AApY8LGXgZRQVHpMe1E4QVG/t0kcEDkYxKtpfWKgpZCS46dBB9UnqJBzneF00P5ZsA5c8yLOrEgoARsTCiko3HngB04IsBx7Q3UUnTMHAypAYHuDIugRwwI/CIvZcoqOSo+6O0BYxpNPuUgmwFuoh1VYtoKHnzHyjeR5GBZsHXY47QzRUJb52f7q+nfEyT4srixvdRmlRUSGUkMoxB12YzQ1VeBld1/nBHqKuMciJqJzi4sVi+kNBWG5hy48vB55lV9fDNJzjasppGW9o7jB2kqeRMj95sRyfgg4yJBhyAlzDpGReJt4CsSKEGepkUq8xwG6nrCLfKVcV8+srTKguDyHWYbSTC77PKrWodWLTOCliSYQM2AE59IAGZW1LsMrsIvYpJuRVwsnpOwkgWB9WSJJcFcHeXKq+WcnfpvCjEr7DIgcZVfntyk6wazt12xGqs8vbYHkYRUBa2NgfnMLRSf8Ao9acS5HSTuUcI3EQPlggfjFWPMOJhelVeSp9Kx3UgiXhFCDjG8tqZFUZ5g9JbeisqtV+PtM3FI4lTaK14rAFXIQjBlp0KYYsd8Zz3kkXKAdRIsLOEAnHCfrC7HUElyrAlqKP5YBKn7pxviFVUV1q1pIyo5GH6WqpPUTzGF9jBVrIbgYEkk745GG43obUmDKTqrSjDAJ2J6Qi6j4W7yFOAAOM9yZTwvXeQATnbOJp01NqqBxENYowwPM9prYYobrXkC1lIROMHOfaDJUtlFnHzGMTUuqrVVD5bA+6IO1J07q4raxWBypip8G5MX1XXBmtSUYCwfKR1ijgyvaFsAbsBsg95Bq1ClGO4j2crx8NIy/uJjqY9K4Jcy96vMcKoOScAS/XaYaewIvLhH1xHtXRzLDKm/CM9gcyJ5Qmuo2Nw4+UqdQMjrNJOL7lQlxHEgQdcbSKVkgnEsAKLxMN9gIBEQGAm564Eq1PHW3CSQRDLUFdKEkZIyD22gOps8x88z3k27LySiuSC7GWjlIK/cZlgCtybHzjEkMB7S+njWz08xKwhXfAOYVSynCsOF15MOvsZrRSC5Hs4sEspH4SqtyjZEP0z1pWfMwcHJRjsRKbtMCvm6fkf7kVF5RummSpCvzO45e8IrK1qOvcCZ4JAyw4fkYTRYrWruGHXMxwKY8qTo1LERtMbawc4G2OUbTiu7TgAepjgg8xGV+FGVdgRg46wasjixYrGvPQ7yaTo7ZZIpoMOlehm9Q4Owl6Cu4MEINi45HYwezXpjgQ7HnmE0aQEjUVMTkcscj2iyuuS+Pa5Vj5B0Xi1bVnpvgdflHZLqrC9IPCG5dpLUr5OtW3HDxDmOk0NPngJturdThgvYQcuAhj3Np8GZ4gWNK2qAHU8u0uXUV2lVYENw7Y3Gf9oRq6qb1sSphnmcmVeGVqlLobl4j0Ix+ZhuTgK4tZaXZmTeFTUZIwo54lJPFxYAJHXO8O8R05R8cJAzj5mV6evgOXVQP+reOpcHJPFLe0U+FIG8XoV+/5yzxpf+MYAbCWVKa9cl6KPvjBEI11JfWuxAO2Zjf6iY8cf7Zw82Y5RaKhZsXfYb8oDwcTe5h2uqYtnkJVUgH3uYl0+LPMnFuW0qZGAwJKgt5g4x6cYBMmzc5S7M+2+Jm6w2bOSOrs42wOQ5GCEZl7LKyMQpIjO5OyXDFwwv4eL4czbQ+xg68S8parHmefeWigyQoM1NGqLI5DDcZ/SNS71PkcuoMvFEl8OZvA1MpYh2JKjfv0kQnAciFfDx/hziFrwFNlKXWAjJ2Ev81XO2VJ+kXw8rtKUAG11UdOI4mcDbpR7jX1kWjh3+UN8P1dqkKjgN0LHlM+3xHSqrZclgNlUQJvFiGylOO3E2YspRrkFl6c90Wd2nl6nSs9oVLUx6ujH2Ex9ZrLg4Xb09R1mH/SPVthTXXwgEEAkfnB/wBr3E5epD9RIwcV3OrNrXNfSdNb4gL6FbBW5f3VAAEJ8L8QpZGpvrDZOcqN5yVPi3Cf62nAPMqf0mhpPEtOrEq6Kf3mGI7UGqQkNZPepNnWai7TcNXHgHqh5iUarw6m9Wu0F4IxlkJ3mIA2qHGrFweo5Q7w3UWaJsMvFWTkqZN49quL5O6OqWR1NcfJUtFi+kg59hyhOqdqW9QPE2CSw6dJsVfD6g+am7DBKk7j9f8A7MrVqz+IWHBNSrxAAZyB09pLqfVyjreCofQzJ1/quO33sHHaZtjcLGH6lw1jsW3J3B2gqVGyzltKqfB5mXFc3RSFYjMRUjpD7VLAV0ry5nvK3p8rd2Ge3aEZCzwUAlO+0rKiX2HLYAJkeBv3Y1nK4I3F0wPSSGjHaaYqA6SQX2El1D0lgRmfBjtHGiGeU1RWD0kxUO0OoxvboyRo8dJaujz0motSnpLkpHaL1mOtMjJGg9pJdB7TdroB6S3yUXmIvXY3tonC/aS5/DKq1qAFj53IzOVsstvfzHLOx/HadN9ptF4jrvFbn+DPk6cYRkX7y89zMVSprNhuWggEKqqfV2B+cqpWjxNRfUa8AhpsGPQRnlkc4kr4iMjHfM0qLMBU1QBUbcJG6fP67fjDq9NRYylDktv6T02G4iSlRuHFvdGOmjZ2ARST7SLafhByMTt9L4QEVXNTEf4gX047bwbW+EtVXxMjcQHr9JPD2P5flILOro7paFqNnFcBA9IPvH8uzgB4Gw2wOOc3Wr0mmRXcqcZXgIy2xO522585nXNY78TMVrU77ZNYJ6/p7ToTs87Jj2so02s1OifNFhRc7qRsfmJ23hrV67w+rUL95l9WO84u5kRfLLh0bPrIwRvOq+wK6iyq5XqT4ZD6HIweL9ZspUrLaKX6mx9jWq01iEsuw/OHearIUWrOeWefvDa9KjWqHYBW6wvUhdKq/DVBgeoX9ZzZMsfKPc08ciltg6OI8T0OoZgtdBwx7coC+geg4NmW6gchOv1A1dpPFWEU8veZlugffzCu/bYScc7bo68mjg1ub5MZFJHAGwBz3lNtSk7N9BN1NBpxgWuu3aGVabRLuUyJXrJHLLTb+EcmtJUHhqJPciVPXcT9wzrr7NKgIrp/KZGquYt6Kif9MpHMmc2bSOKNAavT/wCdV/EI41Om63V/xiedgDtJADtLdJHnr1Cfwei/F6Yf49X8YjjW6b/Pq/jE88GOwkwJnRQy18/g9ETXaXO+opH+sQivX6PrqqB/5BPNlAPSWqq9oe3T8jrXz+D01NfoMb6zT/8AsEVuv0R2XV0H5WCecKibZ/lCaa0OIvtUvJWOtk/B3jXaG+l6bdRQUsUqwLjcHnMaz7PeBZIS1eEjAUWjC+4mXRTUecNqppx1MzpbfJaoZf5Iuu+znh7aSxNLrALWYEcRU9ffp7Z/2lGl+zup0+qRUuptGOItWQB8jy3hSKgG0O0ViAgg/WSyRbXcvi0+OLtHZ/ZSvRaEOPGPIsTPpsOCpOJjfajwz42699KUrpOPLQlcsN+/6zC+12tNfgLsjYxYmcGbNty21g52PLacSxytFI4k8ze45er7HWXZOq8QqpXi5LhmI999oePsV4IEw+oZwcbtbvL9RWp3yZm301knJM7Ixk13Jz0uK7qzUp+yX2dQs7mliNwr2ZH4DPtDqqvDtLWKqH09da8lXAAnI2aev95oFqKVXbP1Mf28n9xLdDF2ijvWu0Y/5mr+MQW7xTS1nC31EjrkTzyytehlDovbM16PcqciS16g72/k767xWh8g3p+UE/aGlJ/tKvwUThmRe0rIHaJ7FL7hn6zLxD8nfftLSqPv1/UfpGPi+mxzp/EiefkY5SBHtN9kvkx+tT/qd5Z4zRuFsrHyMAu8VqZsm0TjyB+6PpGIHaOtJFeTnn6vN/ah8yQkMxxOs8iywGSDStY/Eo5kQNTLg0sVx7fWBHUVjkST7RvjQP7h+szchtxqJZ85fXYO/wDOYnxzdEH4mOPEbRyVPzhvQyy0dNTdjr+g/lC69QCdm+hnJL4tqANlr/P/AHkbPE9S6kcQXP7sRyR0R1O07K3XVU15e1Qfny+sA/pNVU39UrWe/KckzMxyzE/MxsmSlFMo9fk+3g6Hxb7Q2eKaU6d6gqEjkcnaH0/bKyusK+n4iOobYzkOKLjMTpoxa7Mpbr5O5p+12luGNQjVE+2ZYfEKL1zVcrf9uTOAyY6synK7GPGNDP1DJLiXJ276kEkcWflmCXWkjlmc4viGqUf2pi/aV558P0llJEJaizYsf5/WUPYJmHXWnmE+kb42z91Y29EXkDmeQLQT4s9V/OS+JQ8wQYbkLuLi0iTGDqw2IkTNFscmNEZHMBRuIDrIm4ASjMUm5MCbWs3I4EgSTFFEAUUUUAFFFFABxHzIxQNTJRRhHgMKKKNmYFjkxZkcxTRbHJjRRQMFFFFABRRRQAbrtLFsZeuRIRQsC4WjqJLjU9YPFG3sD//Z"))),
                            ),
                            ListTile(
                                title: Text(
                                  snapshot.data![index].header,
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      snapshot.data![index].title,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Detail(
                                                          blog: snapshot
                                                              .data![index],
                                                        )));
                                          },
                                          child: Container(
                                            //color: Colors.blue,
                                            padding: EdgeInsets.all(4),
                                            child: Center(
                                              child: Text(
                                                "read more..",
                                                style: TextStyle(
                                                    color: Colors.blue),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                )),
                          ],
                        ),
                      ),
                    );
                  }),
                );
              }
              return Center(child: CircularProgressIndicator());
            }));
  }
}
